import React from "react";
import ColorChanger from "./Components/ColorChanger";

export default function App() {

  return (
    <>
      <h1>RITHIK RAJ K S    😎</h1>
      <ColorChanger />
    </>
  );
}